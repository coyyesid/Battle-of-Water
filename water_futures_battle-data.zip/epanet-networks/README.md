The EPANET networks released are purely for visualization purposes.

There are two types of networks
- Network files named `visualise_topology` have only the currently installed pipes and the active sources.
We recommend inspecting these networks using the EPANET.js web interface, which allows you to view them overlaid directly on the map of the Netherlands.
This should give you a better understanding of the system.

- Network files named `visualise_full_options` have all possible sources (but unconnected) and all possible connections (pipe diameter 0.0001 mm and roughness 128).
We suggest open these networks with the EPANET for Windows application, turn on visualization of the link by "diameter", and "red pipes" should be currently installed pipes, while "blue pipes" should be possible connections.

You can use these networks as a starting point for your models.
However, the Excel files are the ground truth describing all problem entities.
While the topology reflects the actual system, other parameters (demands, electricity prices, etc.) will be dynamically modified by the evaluator.
Thus using these networks will not reproduce the actual hydraulic behavior used in evaluation.
